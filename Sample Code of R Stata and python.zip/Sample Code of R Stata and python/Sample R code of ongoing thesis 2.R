install.packages("caTools")
install.packages("quantmod")
install.packages("MASS")
install.packages("corrplot")
install.packages("car")
library(caTools)
library(car)
library(quantmod)
library(MASS)
library(corrplot)
corrplot(cor(Data_for_R), method = "number")
cor(Data_for_R)
install.packages("dplyr")
library(dplyr)
mydata <- select(Data_for_R, c(2, 3, 4, 12, 13, 14, 15, 16, 
                               17, 18, 19, 20))
cor(mydata)
mean(cor(mydata))
PCA = princomp(mydata)
PCA$loadings
PC = PCA$scores
View(PC)
cor(PC)
biplot(PCA)
PCA2 <- prcomp(mydata, scale = TRUE)
summary(PCA2)
PCA2$rotation
my.var = varimax(PCA2$rotation)
my.var
loadings <- PCA2$rotation[, 1:3]
projected_data <- scale(mydata) %*% loadings
print(head(projected_data))
PCA2 = prcomp(mydata)
PCA2$x
summary(PCA2)
biplot(PCA2)
PCA$scores == PCA2$x
explained_variance <- PCA2$sdev^2
total_variance <- sum(explained_variance)

proportion_of_variance <- explained_variance/total_variance
print(proportion_of_variance)
prop_variance <- PCA2$sdev^2/sum(PCA2$sdev^2)
print(prop_variance)
pca_data <- as.data.frame(predict(PCA2))
pca_data
pca_data$co2_emissions <- Data_for_R$co2_emissions
pca_data$crop_va <- Data_for_R$crop_va
pca_data$livestock_va <- Data_for_R$livestock_va
pca_data$fishing_va <- Data_for_R$fishing_va
pca_data$forestry_va <- Data_for_R$forestry_va
pca_data$healthcare_spending_pc <- Data_for_R$healthcare_spending_pc
pca_data$nat_dis_dam <- Data_for_R$nat_dis_dam
print(head(pca_data))
eigen(PCA)
e.scaled = eigen(cov(pca_data))
print(e.scaled)
cor(pca_data)
e.scaled$values
e.scaled$values/17
cumsum(e.scaled$values/17)
install.packages("pls")
library(pls)
pcr_model <- pcr(crop_va + livestock_va + fishing_va + forestry_va + 
                   healthcare_spending_pc + nat_dis_dam ~ ., data = pca_data, 
                 scale = TRUE, validation = "CV")
summary(pcr_model)
pcr_one <- lm(crop_va ~ co2_emissions + PC1 + PC2 + PC3, 
              data = pca_data)
  summary(pcr_one)
1/(1 - 0.9515)
pcr_1 <- lm(livestock_va ~ co2_emissions + PC1 + PC2 + PC3, 
            data = pca_data)
summary(pcr_1)
pcr_2 <- lm(forestry_va ~ co2_emissions + PC1 + PC2 + PC3, 
            data = pca_data)
summary(pcr_2)
pcr_3 <- lm(fishing_va ~ co2_emissions + PC1 + PC2 + PC3, 
            data = pca_data)
summary(pcr_3)
pcr_two <- lm(healthcare_spending_pc ~ co2_emissions + PC1 + 
                PC2 + PC3, data = pca_data)
summary(pcr_two)
pcr_three <- lm(nat_dis_dam ~ co2_emissions + PC1 + PC2 + 
                    PC3, data = pca_data)
summary(pcr_three)
mlr_1 <- lm(crop_va ~ co2_emissions + ` gdp_pc` + population + 
              urban + ren_energy_con + arable_land + fdi_inflows, data = Data_for_R)
summary(mlr_1)
mlr_2 <- lm(livestock_va ~ co2_emissions + ` gdp_pc` + population + 
              urban + ren_energy_con + arable_land + fdi_inflows, data = Data_for_R)
summary(mlr_2)
mlr_3 <- lm(forestry_va ~ co2_emissions + ` gdp_pc` + population + 
              urban + ren_energy_con + arable_land + fdi_inflows, data = Data_for_R)
summary(mlr_3)
mlr_4 <- lm(fishing_va ~ co2_emissions + ` gdp_pc` + population + 
              urban + ren_energy_con + arable_land + fdi_inflows, data = Data_for_R)
summary(mlr_4)
mlr_5 <- lm(healthcare_spending_pc ~ co2_emissions + ` gdp_pc` + 
              population + urban + ren_energy_con + arable_land + fdi_inflows, 
            data = Data_for_R)
summary(mlr_5)

mlr_6 <- lm(nat_dis_dam ~ co2_emissions + ` gdp_pc` + 
              population + urban + ren_energy_con + arable_land + 
                fdi_inflows, data = Data_for_R)
summary(mlr_6)
cor(DataforR)
mean(cor(DataforR))
install.packages("vars")
library(vars)
data <- ts(data.frame(Data_for_R))
ardl_model <- VAR(data, p = 2, type = "both")
summary(ardl_model)
irf(ardl_model)
forecast(ardl_model)
install.packages("dynamac")
install.packages("forecast")
install.packages("tidyverse")
install.packages("tseries")
install.packages("urca")
install.packages("TSstudio")
install.packages("dynlm")
library(dynlm)
library(dynamac)
library(forecast)
library(tidyverse)
library(tseries)
library(urca)
library(TSstudio)
install.packages("ARDL")
library(ARDL)
install.packages("dLagM")
library(dLagM)
`?`(ts)
data <- ts(Data_for_R, start = c(2000), frequency = 1)
co2 <- ts(Data_for_R$co2_emissions, start = c(2000), frequency = 1)
crop_va <- ts(Data_for_R$crop_va, start = c(2000), frequency = 1)
gdp_pc <- ts(Data_for_R$gdp_pc, start = c(2000), frequency = 1)
ts.plot(co2, Xtitle = "Date", Ytitle = "co2_emissions", title = "CO2 emissions")
ts.plot(crop_va, Xtitle = "Date", Ytitle = "crop_va", title = "value added by crop")
ts.plot(gdp_pc, Xtitle = "Date", Ytitle = "gdp", title = "GDP")
PP.test(co2)
PP.test(crop_va)
PP.test(gdp_pc)
res1 <- dynardl(crop_va ~ co2_emissions, data = Data_for_R, 
                lags = list(crop_va = 1, co2_emissions = 1), diffs = "co2_emissions", 
                ec = TRUE, simulate = FALSE)
summary(res1)
dynardl.auto.correlated(res1)
regress <- dynlm(formula = crop_va ~ co2_emissions, data = Data_for_R, 
                 p = 2, q = 2)
summary(regress)
install.packages("vtable")
library(vtable)
summary.table(Data_for_R)
sumtable(Data_for_R)
install.packages("Hmisc")
  installed.packages("xlsx")

library(Hmisc)
library(xlsx)
install.packages("corrplot")

library(corrplot)
corrplot(cor(Data_for_R), method = "number")
corrplot(cor(Data_for_R$co2_emissions, Data_for_R$population, 
               Data_for_R$econ_growth_rate, Data_for_R$ren_energy_con, 
               Data_for_R$gdp_pc, Data_for_R$temp_change, Data_for_R$urban, 
               Data_for_R$arable_land, Data_for_R$fdi_inflows, Data_for_R$annual_rainfall, 
               Data_for_R$res_dev))
cor(Data_for_R)
summary_statistics <- sumtable(Data_for_R)
summary_stats <- summary(Data_for_R)
summary(Data_for_R)
write.xlsx(as.data.frame(results$r), file = "results.xlsx")
install.packages("writexl")
library(writexl)
write_xlsx(as.data.frame(summary_statistics), path = "summary_statistics.xlsx")
write_xlsx(as.data.frame(summary$Data_for_R), "Summary_Statistics.xlsx")

install.packages("neuralnet")
 install.packages("grid")

install.packages("MASS")

 library(MASS)
library(grid)
library(neuralnet)
require(neuralnet)
`?`(neuralnet)
attach(Data_for_R)
scaleddata = scale(Data_for_R)
scaleddata = scale(pca_data)
normalize = function(Data_for_R) {
return((Data_for_R - min(Data_for_R))/(max(Data_for_R) - 
                                         min(Data_for_R)))

normalize_pca = function(pca_data) 
  return((pca_data - min(pca_data))/(max(pca_data) - min(pca_data)))

maxmindf = as.data.frame(lapply(Data_for_R, normalize))


maxmindf = as.data.frame(lapply(pca_data, normalize_pca))

maxmindf
maxmindf
nn = neuralnet(crop_va ~ co2_emissions + population, data = Data_for_R, 
               hidden = c(2, 1), linear.output = FALSE, threshold = 0.01)

nn$result.matrix

nn = neuralnet(crop_va ~ co2_emissions + PC1 + PC2 + PC3, 
               data = pca_data, hidden = c(2, 1), linear.output = FALSE, 
               threshold = 0.01)
nn$result.matrix
install.packages("lmtest")
library(lmtest)
grangertest(crop_va ~ co2_emissions, order = 1, data = Data_for_R)
grangertest(crop_va ~ co2_emissions, order = 1, data = Data_for_R)
grangertest(livestock_va ~ co2_emissions, order = 1, data = Data_for_R)
grangertest(forestry_va ~ co2_emissions, order = 1, data = Data_for_R)
grangertest(fishing_va ~ co2_emissions, order = 1, data = Data_for_R)
grangertest(healthcare_spending_pc ~ co2_emissions, order = 1, 
            data = Data_for_R)

grangertest(healthcare_spending_pc ~ co2_emissions, order = 2, 
              data = Data_for_R)
grangertest(nat_dis_dam ~ co2_emissions, order = 2, data = Data_for_R)
install.packages("devtools")
library(devtools)
install.packages("NeuralNetTools")
library(NeuralNetTools)
garson(Data_for_R)
`?`(garson)
install.packages("car")
library(car)
vif(pcr_one)
vif(mlr_1)
install.packages("glmnet")
library(glmnet)

y1 <- Data_for_R$crop_va

y2 <- Data_for_R$livestock_va
y3 <- Data_for_R$forestry_va
y4 <- Data_for_R$fishing_va
y5 <- Data_for_R$healthcare_spending_pc
y6 <- Data_for_R$nat_dis_dam
x <- data.matrix(Data_for_R[, c("co2_emissions", "gdp_pc", 
                                  "population", "urban", "ren_energy_con", "arable_land", 
                                  "fdi_inflows", "inflation", "unemp", "econ_growth_rate", 
                                  "temp_change", "annual_rainfall", "res_dev")])

model1 <- glmnet(x, y1, alpha = 0)

summary(model1)
cv_model1 <- cv.glmnet(x, y1, alpha = 0)
plot(cv_model1)
best_lambda <- cv_model1$lambda.min
best_lambda
plot(model1, xvar = "lambda")
best_model1 <- glmnet(x, y1, alpha = 0, lambda = best_lambda)

coef(best_model1)
y_predicted <- predict(model1, s = best_lambda, newx = x)
sst <- sum((y1 - mean(y1))^2)
sse <- sum((y_predicted - y1)^2)
rsq <- 1 - sse/sst
rsq